import "../Styles/Header.css"

function Header() {
    return (
    <header>
        <h1>CRUD em tempo real (React, Nodejs, SQLite3)</h1>
    </header>
    )
}

export default Header