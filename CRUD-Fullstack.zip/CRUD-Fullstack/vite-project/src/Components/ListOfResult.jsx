import React, { usestate, useeffect } from "react";
import { Link } from "react-rputer-dom";
import "../Styles/ListofResult.css";

function ListofResult() {

// Guarda e atualiza as informacoes recebidas do backend.
const [result, setResult] = usestate([]);

// Faz a solicitação das informações no backend quando a pagina É CARREGADA.
useEffect(()=> {
    fetch("http://localhost:3000")
        .then((res) => res.json())
        .then((data) => {
            setResult(data);
            console.log(data);
})
    .catch((err) => {
        console.error(err);
});
}, []);

    const handleDelete = (e) => {
        console.log(e.target.name);

        if (confirm("Tem certeza que deseja excluir estas informações?")) {
            console.log("Informação excluída");
            fetch("http://localhost:3000", {
                method: "DELETE",
                body: JSON.stringify({
                    ["ProductID"]:e.target.name,
                }),
                headers: { "Content-Type": "application/json" },
            });
            window.location.reload();
        } else {
            console.log("Pedido de exclusão cancelado.");
        }};

return (
    <div className="results">
        <h1 className="title_results">Resultados</h1>
        <section className="section_all_results">
            {result.map((item, index) => (
                <section key = {index} className="section_individual_result"> 
                    <article>
                    <p className="p_results">Nome Produto</p>
                    <p className="product_result">{item.ProductName}</p>
                    <p className="p_results">Fornecedor ID</p>
                    <p className="product_result">{item.SupplierID}</p>
                    <p className="p_results">Categoria ID</p>
                    <p className="product_result">{item.CategoryID}</p>
                    <p className="p_results">Unidade</p>
                    <p className="product_result">{item.Unit}</p>
                    <p className="p_results">Preço</p>
                    <p className="product_result">{item.Price}</p>
                    </article>

            <div className="div_buttons_results">
                <Link to = {`/modify/${item.ProductID}`}>
                    <button className="modify_results">modificar</button>
                </Link>
                <button
                    name={item.ProductID}
                    onClick={handleDelete}
                    className="delete_results">
                    Excluir
                    </button>
            </div>
        </section>
        ))}
    </section>
</div>
);
}

export default ListofResult;