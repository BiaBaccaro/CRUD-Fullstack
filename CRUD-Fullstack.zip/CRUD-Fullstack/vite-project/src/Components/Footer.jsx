import "../Styles/Footer.css"

function Footer() {
    return (
        <footer>
            <p className="copyright">2024 - Escola Senai</p>
        </footer>
    )
}

export default Footer